const github_database_1_token = "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";
const github_repo_owner = "Rickware-Labs";
const github_repo_name1 = "Launcher-Database-1";
const github_account_file_path = "Launcher-Database/database/accounts/accounts.json";
const github_account_images_path = "Launcher-Database/database/account_images";

const github_database_2_token_read_only = "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";
const github_repo_name2_read_only = "Launcher-Database-2";
const github_website_config_file_path_read_only = "Launcher-Database/database/website_config/config.json";
const github_account_file_path_read_only = "Launcher-Database/database/accounts/accounts.json";
const github_account_images_path_read_only = "Launcher-Database/database/account_images";
const github_products_file_path_read_only = "Launcher-Database/database/products/products.json";
const github_products_images_path_read_only = "Launcher-Database/database/product_images";